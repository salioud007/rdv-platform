function direBonjour() {
  document.getElementById("message").textContent = "Bienvenue chez nous, assieds-toi, le riz gras arrive !";
}
